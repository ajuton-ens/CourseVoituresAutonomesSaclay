/*
 * CoVAPSy_moteurs.h
 *
 *  Created on: May 21, 2023
 *      Author: ajuton
 */
#include "tim.h"
#include <stdint.h>
#include "u8g.h"
#include "i2c.h"


#define ADDRESS_TF051 0x3C

#ifndef INC_COVAPSY_TF051_H_
#define INC_COVAPSY_TF051_H_

void u8g_Delay(uint16_t val);
void u8g_xMicroDelay(uint16_t val);
void u8g_MicroDelay(void);
void u8g_10MicroDelay(void);
uint8_t u8g_com_arm_stm32_sh_i2c_fn(u8g_t *u8g, uint8_t msg, uint8_t arg_val, void *arg_ptr);
void tf051_init(u8g_t *pu8g);

#endif /* INC_COVAPSY_TF051_H_ */
