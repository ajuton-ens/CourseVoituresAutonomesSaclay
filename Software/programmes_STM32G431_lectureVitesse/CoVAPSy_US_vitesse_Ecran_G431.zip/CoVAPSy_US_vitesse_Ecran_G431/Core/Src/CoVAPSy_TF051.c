/*
 * CoVAPSy_moteurs.c
 *
 *  Created on: May 21, 2023
 *      Author: ajuton
 */
#include "CoVAPSy_TF051.h"


uint8_t control = 0;

void u8g_Delay(uint16_t val) {
    HAL_Delay(val);
}
void u8g_xMicroDelay(uint16_t val) {
    static uint32_t i, j;
    static uint32_t freq;
    freq = HAL_RCC_GetSysClockFreq() / 1000000;

    for (i = 0; i < val;) {
        for (j = 0; j < freq; ++j) {
            ++j;
        }
        ++i;
    }
}
void u8g_MicroDelay(void) {
    u8g_xMicroDelay(1);
}
void u8g_10MicroDelay(void) {
    u8g_xMicroDelay(10);
}

uint8_t u8g_com_arm_stm32_sh_i2c_fn(u8g_t *u8g, uint8_t msg, uint8_t arg_val, void *arg_ptr) {
    switch (msg) {
    case U8G_COM_MSG_STOP:
        break;

    case U8G_COM_MSG_INIT:
        u8g_MicroDelay();
        break;

    case U8G_COM_MSG_ADDRESS:
        if (arg_val == 0) {
            control = 0;
        } else {
            control = 0x40;
        }
        u8g_10MicroDelay();
        break;

    case U8G_COM_MSG_WRITE_BYTE: {
        HAL_I2C_Mem_Write(&hi2c1, ADDRESS_TF051<<1, control, 1, &arg_val, 1, 10000);
    }
        break;

    case U8G_COM_MSG_WRITE_SEQ:
    case U8G_COM_MSG_WRITE_SEQ_P: {
        HAL_I2C_Mem_Write(&hi2c1, ADDRESS_TF051<<1, control, 1, arg_ptr, arg_val, 10000);
    }

        break;
    }
    return 1;
}

void tf051_init(u8g_t *pu8g){
	u8g_InitComFn(pu8g, &u8g_dev_sh1106_128x64_i2c, u8g_com_arm_stm32_sh_i2c_fn);
	u8g_Begin(pu8g);
}
