/*
 * CoVAPSy_buzzer.c
 *
 *  Created on: May 18, 2023
 *      Author: ajuton
 */


#include "CoVAPSy_buzzer.h"

//Periode max 65 535 µs => Frequence entre 15 et 1 MHz
void buzzer_start_frequency_Hz(float frequency_Hz){
	uint32_t periode_buzzer;
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
	periode_buzzer = FREQ_TIMER_4/frequency_Hz;
	htim4.Instance->ARR=periode_buzzer+1;
	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, periode_buzzer/2);
}

void buzzer_start(void){
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
}

void buzzer_stop(void){
	HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
}

void buzzer_gamme(void){
	buzzer_start_frequency_Hz(NOTE_DO3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_RE3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_MI3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_FA3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_SOL3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_LA3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_SI3);
	HAL_Delay(500);
	buzzer_start_frequency_Hz(NOTE_DO4);
	HAL_Delay(500);
	buzzer_stop();
}
