/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "CoVAPSy_buzzer.h"
#include "CoVAPSy_bno055.h"
#include "CoVAPSy_moteurs.h" //Pas utilisé pour ce programme, les moteurs sont commandés par la RPI
#include "CoVAPSy_TF051.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BP_ENFONCE 0
#define BP_RELACHE 1
#define DISTANCE_1_TOUR_AXE_TRANSMISSION_MM 79
#define ADDRESS_SRF10 0x70


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
int16_t roll, distance_US;
uint8_t temp;
static u8g_t u8g;
float vitesse_mesuree_m_s = 0;
int32_t vitesse_mesuree_mm_s = 0;
uint8_t drapeau;
uint32_t tensionBatterie;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void cmd_vitesse_0_1(float commande_0_1); //Pas utilisée ici
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	uint32_t bp1,bp2,bp1_old=0,bp2_old=0;
	uint8_t donnees_Tx_i2c[8];
	uint8_t donnees_Rx_i2c[8];
	char text[50];

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_TIM6_Init();
  MX_I2C1_Init();
  MX_ADC2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); //propulsion
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4); //direction
  buzzer_start();
  bno055_init();
  HAL_TIM_Base_Start_IT(&htim6);
  ///////////////////////////////////////////////////////////////////
  tf051_init(&u8g);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
	  //démarrage de la conversion ADC pour la mesure de tension batterie
	  HAL_ADC_Start(&hadc2);

	  bp1 = HAL_GPIO_ReadPin(BP1_GPIO_Port, BP1_Pin);
	  bp2 = HAL_GPIO_ReadPin(BP2_GPIO_Port, BP2_Pin);
	  if((bp1 == BP_ENFONCE) && (bp1_old == BP_RELACHE))
	  {
		  buzzer_gamme();
	  }
	  if((bp2 == BP_ENFONCE) && (bp2_old == BP_RELACHE))
	  {

	  }
	  roll = bno055_lecture_16bits(EULER_ROLL_16bits);
//	  temp = bno055_lecture_8bits(TEMPERATURE_8bits);

	  //Lecture ultrason
	  donnees_Tx_i2c[0]=0x00;
	  donnees_Tx_i2c[1]=0x51;
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);
	  HAL_I2C_Master_Transmit(&hi2c1, (uint16_t)ADDRESS_SRF10<<1, donnees_Tx_i2c, 2, 1000);
	  HAL_Delay(100);
	  donnees_Tx_i2c[0]=0x02;
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);
	  HAL_I2C_Master_Transmit(&hi2c1, (uint16_t)ADDRESS_SRF10<<1, donnees_Tx_i2c, 1, 1000);
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);
	  HAL_I2C_Master_Receive(&hi2c1, (uint16_t)ADDRESS_SRF10<<1, donnees_Rx_i2c, 2, 1);
	  distance_US = (uint16_t)(donnees_Rx_i2c[0]<<8) + donnees_Rx_i2c[1];

	  //attente de la fin de la conversion ADC, si jamais ce n'est pas encore fini
	  while(HAL_ADC_PollForConversion(&hadc2, 100)!=HAL_OK);
	  tensionBatterie = (uint32_t)(HAL_ADC_GetValue(&hadc2)*2.53);


	  //Affichage
	  u8g_FirstPage(&u8g);
		do {
			u8g_SetFont(&u8g, u8g_font_profont12);
			sprintf(text, "--CoVAPSy 2024--");
			u8g_DrawStr(&u8g, 0, 12, text);
			sprintf(text, "vit : %5d mm/s", (int)vitesse_mesuree_mm_s);
			u8g_DrawStr(&u8g, 0, 24,  text);
			sprintf(text,"roulis : %5d", roll);
			u8g_DrawStr(&u8g, 0, 36,  text);
			sprintf(text,"Vbat : %5u mV", tensionBatterie);
			u8g_DrawStr(&u8g, 0, 48,  text);
			sprintf(text,"ultrason : %4d", distance_US);
			u8g_DrawStr(&u8g, 0, 60,  text);
		} while (u8g_NextPage(&u8g));


	  bp1_old = bp1;
	  bp2_old = bp2;


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef* htim)
{
	static uint32_t mesure_precedente_us=0, mesure_us, indice=0, i;
	static uint32_t tableau_intervalles_us[16]={};
	static float coefficient_distance_par_intervalle_us = DISTANCE_1_TOUR_AXE_TRANSMISSION_MM *1000 / 16.0;
	static uint32_t somme_intervalles_us = 0;
	uint32_t nb_intervalles=0;
	//HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin,1);
	mesure_us = __HAL_TIM_GET_COMPARE(&htim2, TIM_CHANNEL_1); // ou TIM2->CCR1
	if((mesure_us-mesure_precedente_us) >= 300) //si mesure cohérente (pas un glitch):
	{
		if((mesure_us > (mesure_precedente_us+100000)) || ((mesure_us-100000) > mesure_precedente_us)) //cas d'un nouveau départ
		{
			for(indice=0;indice<16;indice++)
			{
				tableau_intervalles_us[indice] = 0;
			}
			indice=0;
		}
		else //cas où on tourne depuis plus d'un intervalle
		{
			drapeau = 1;
			tableau_intervalles_us[indice] = mesure_us - mesure_precedente_us; //on sauvegarde la nouvelle mesure dans le tableau
			//On fait une moyenne sur 10 ms au plus ou 16 valeurs.
			somme_intervalles_us = 0;
			i= indice;
			do{
				if(tableau_intervalles_us[i]==0)
						break;
				somme_intervalles_us += tableau_intervalles_us[i];
				i = (i - 1)%16;
				nb_intervalles++;
			}while ((somme_intervalles_us<100000) && (nb_intervalles < 16));
			indice = (indice+1)%16; // on incrémente l'indice avec retour à 0 pour indice = 16
			vitesse_mesuree_m_s = coefficient_distance_par_intervalle_us * nb_intervalles / somme_intervalles_us;
			vitesse_mesuree_mm_s = 1000*vitesse_mesuree_m_s;
		}
		mesure_precedente_us = mesure_us;
	}
	//HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin,0);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
{
	HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin,1);

	//Pour aller à 0.1 m/s, il faudrait remettre la vitesse à 0 si arrêt chaque 2 cycles
	//A 0.1 m/s il y a 30 ms entre deux fronts.
	if (drapeau == 1)
	{
		drapeau = 0;
	}
	else {
		vitesse_mesuree_m_s=0;
		vitesse_mesuree_mm_s = 1000* vitesse_mesuree_m_s;
	}
	HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin,0);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
